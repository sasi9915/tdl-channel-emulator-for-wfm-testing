library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;

entity coeff_reload_sequencer is
    generic(
        G_RELOAD_WORD_COUNT : integer  := 32;
        G_MAX_SET_COUNT     : positive := 600;
        G_COEFF_WIDTH       : integer  := 16;
        G_CONFIG_WIDTH      : integer  := 8;
        G_FIFO_DEPTH        : integer  := 512
    );
    port(
        aclk                : in  std_logic;
        aresetn             : in  std_logic;
        enable              : in  std_logic;
        clear_status        : in  std_logic;
        fu_period_cycles    : in  unsigned(31 downto 0);
        block_set_count     : in  integer range 1 to G_MAX_SET_COUNT;
        refill_threshold_sets : in integer range 0 to G_MAX_SET_COUNT;
        coeff_set_tvalid    : in  std_logic;
        coeff_set_tready    : out std_logic;
        coeff_set_tdata     : in  std_logic_vector((2 * G_COEFF_WIDTH) - 1 downto 0);
        real_reload_tvalid  : out std_logic;
        real_reload_tready  : in  std_logic;
        real_reload_tdata   : out std_logic_vector(G_COEFF_WIDTH - 1 downto 0);
        real_reload_tlast   : out std_logic;
        imag_reload_tvalid  : out std_logic;
        imag_reload_tready  : in  std_logic;
        imag_reload_tdata   : out std_logic_vector(G_COEFF_WIDTH - 1 downto 0);
        imag_reload_tlast   : out std_logic;
        real_config_tvalid  : out std_logic;
        real_config_tready  : in  std_logic;
        real_config_tdata   : out std_logic_vector(G_CONFIG_WIDTH - 1 downto 0);
        imag_config_tvalid  : out std_logic;
        imag_config_tready  : in  std_logic;
        imag_config_tdata   : out std_logic_vector(G_CONFIG_WIDTH - 1 downto 0);
        reload_active       : out std_logic;
        reload_set_done     : out std_logic;
        reload_block_done   : out std_logic;
        missed_refill       : out std_logic;
        refill_request      : out std_logic;
        refill_request_pulse : out std_logic;
        reload_timing_error : out std_logic;
        dbg_fu_tick_o       : out std_logic;
        dbg_next_state_o    : out std_logic_vector(2 downto 0);
        dbg_reload_accept_o : out std_logic;
        dbg_config_accept_o : out std_logic;
        dbg_timing_fault_o  : out std_logic;
        dbg_reload_word_index_o : out std_logic_vector(15 downto 0);
        dbg_reload_set_index_o  : out std_logic_vector(15 downto 0);
        dbg_seq_fifo_usedw_o    : out std_logic_vector(15 downto 0);
        dbg_seq_fifo_has_set_o  : out std_logic;
        dbg_seq_input_ready_o   : out std_logic;
        state_debug         : out std_logic_vector(2 downto 0)
    );
end entity;

architecture rtl of coeff_reload_sequencer is

    ------ component section

    component xpm_fifo_sync_wrap is
        generic(
            g_TYPE                   : string  := "block";
            g_DATA_WIDTH             : natural := 10;
            g_DEPTH                  : natural := 1024;
            g_FWFT_MODE_ENA          : boolean := true;
            g_ALMOST_FULL_THRESHOLD  : integer := 128 - 8;
            g_ALMOST_EMPTY_THRESHOLD : integer := 8
        );
        port(
            i_resetn       : in  std_logic;
            i_clk          : in  std_logic;
            i_wrreq        : in  std_logic;
            i_data         : in  std_logic_vector(g_DATA_WIDTH - 1 downto 0);
            i_rdreq        : in  std_logic;
            o_q_val        : out std_logic;
            o_q            : out std_logic_vector(g_DATA_WIDTH - 1 downto 0);
            o_usedw        : out std_logic_vector(15 downto 0);
            o_full         : out std_logic;
            o_empty        : out std_logic;
            o_almost_full  : out std_logic;
            o_almost_empty : out std_logic
        );
    end component;

    constant C_FIFO_WIDTH : integer := 2 * G_COEFF_WIDTH;

    type t_state is (s_idle, s_wait_fu, s_reload, s_config, s_advance, s_fault_hold);

    signal state      : t_state := s_idle;
    signal next_state : t_state := s_idle;

    signal r_fu_counter : unsigned(31 downto 0) := (others => '0');
    signal w_fu_tick    : std_logic;

    signal r_set_index         : integer range 0 to G_MAX_SET_COUNT - 1     := 0;
    signal r_reload_word_index : integer range 0 to G_RELOAD_WORD_COUNT - 1 := 0;

    signal r_real_reload_valid : std_logic                                    := '0';
    signal r_imag_reload_valid : std_logic                                    := '0';
    signal r_real_reload_data  : std_logic_vector(G_COEFF_WIDTH - 1 downto 0) := (others => '0');
    signal r_imag_reload_data  : std_logic_vector(G_COEFF_WIDTH - 1 downto 0) := (others => '0');
    signal r_reload_last       : std_logic                                    := '0';

    signal r_real_config_valid : std_logic := '0';
    signal r_imag_config_valid : std_logic := '0';

    signal r_reload_set_done     : std_logic := '0';
    signal r_reload_block_done   : std_logic := '0';
    signal r_missed_refill       : std_logic := '0';
    signal r_refill_request      : std_logic := '0';
    signal r_refill_request_pulse : std_logic := '0';
    signal r_reload_timing_error : std_logic := '0';

    signal w_fifo_resetn                       : std_logic;
    signal w_xpm_sync_i_buffer_fifo_wrreq      : std_logic;
    signal w_xpm_sync_fifo_i_fifo_rdreq        : std_logic;
    signal w_xpm_sync_fifo_i_buffer_fifo_q     : std_logic_vector(C_FIFO_WIDTH - 1 downto 0);
    signal w_xpm_sync_fifo_i_buffer_fifo_usedw : std_logic_vector(15 downto 0) := (others => '0');
    signal w_fifo_usedw_unsigned               : unsigned(15 downto 0);
    signal w_fifo_full                         : std_logic;
    signal w_fifo_empty                        : std_logic;

    signal w_set_input_ready       : std_logic;
    signal w_fifo_has_complete_set : std_logic;
    signal w_reload_last           : std_logic;
    signal w_real_reload_accepted  : std_logic;
    signal w_imag_reload_accepted  : std_logic;
    signal w_reload_accepted       : std_logic;
    signal w_real_config_accepted  : std_logic;
    signal w_imag_config_accepted  : std_logic;
    signal w_config_accepted       : std_logic;
    signal w_timing_fault_candidate : std_logic;

    function f_state_debug(state_value : t_state) return std_logic_vector is
    begin
        case state_value is
            when s_idle =>
                return "000";
            when s_wait_fu =>
                return "001";
            when s_reload =>
                return "010";
            when s_config =>
                return "011";
            when s_advance =>
                return "100";
            when others =>
                return "111";
        end case;
    end function;

begin

    state_debug <= f_state_debug(state);

    process(aclk, aresetn)
    begin
        if aresetn = '0' then
            r_fu_counter <= (others => '0');
        elsif rising_edge(aclk) then
            if fu_period_cycles = to_unsigned(0, fu_period_cycles'length) then
                r_fu_counter <= (others => '0');
            elsif enable = '0' then
                r_fu_counter <= r_fu_counter;
            elsif w_fu_tick = '1' then
                r_fu_counter <= (others => '0');
            else
                r_fu_counter <= r_fu_counter + 1;
            end if;
        end if;
    end process;

    process(aclk, aresetn)
    begin
        if aresetn = '0' then
            state                 <= s_idle;
            r_set_index           <= 0;
            r_reload_word_index   <= 0;
            r_real_reload_valid   <= '0';
            r_imag_reload_valid   <= '0';
            r_real_reload_data    <= (others => '0');
            r_imag_reload_data    <= (others => '0');
            r_reload_last         <= '0';
            r_real_config_valid   <= '0';
            r_imag_config_valid   <= '0';
            r_reload_set_done     <= '0';
            r_reload_block_done   <= '0';
            r_missed_refill       <= '0';
            r_refill_request      <= '0';
            r_refill_request_pulse <= '0';
            r_reload_timing_error <= '0';
        elsif rising_edge(aclk) then
            r_reload_set_done   <= '0';
            r_reload_block_done <= '0';
            r_refill_request_pulse <= '0';

            if clear_status = '1' then
                r_missed_refill       <= '0';
                r_refill_request      <= '0';
                r_reload_timing_error <= '0';
            end if;

            case state is
                when s_idle =>
                    r_set_index         <= 0;
                    r_reload_word_index <= 0;
                    r_real_reload_valid <= '0';
                    r_imag_reload_valid <= '0';
                    r_reload_last       <= '0';
                    r_real_config_valid <= '0';
                    r_imag_config_valid <= '0';

                when s_wait_fu =>
                    if w_fu_tick = '1' then
                        r_reload_word_index <= 0;

                        if w_fifo_has_complete_set = '0' then
                            r_missed_refill <= '1';
                        end if;
                    end if;

                when s_reload =>
                    if r_real_reload_valid = '0' and r_imag_reload_valid = '0' and w_fifo_empty = '0' then
                        r_real_reload_data  <= w_xpm_sync_fifo_i_buffer_fifo_q(C_FIFO_WIDTH - 1 downto G_COEFF_WIDTH);
                        r_imag_reload_data  <= w_xpm_sync_fifo_i_buffer_fifo_q(G_COEFF_WIDTH - 1 downto 0);
                        r_real_reload_valid <= '1';
                        r_imag_reload_valid <= '1';
                        r_reload_last       <= w_reload_last;
                    else
                        if w_real_reload_accepted = '1' then
                            r_real_reload_valid <= '0';
                        end if;

                        if w_imag_reload_accepted = '1' then
                            r_imag_reload_valid <= '0';
                        end if;

                        if w_reload_accepted = '1' then
                            r_reload_last <= '0';

                            if r_reload_word_index = G_RELOAD_WORD_COUNT - 1 then
                                r_real_config_valid <= '1';
                                r_imag_config_valid <= '1';
                            else
                                r_reload_word_index <= r_reload_word_index + 1;
                            end if;
                        end if;
                    end if;

                when s_config =>
                    if w_real_config_accepted = '1' then
                        r_real_config_valid <= '0';
                    end if;

                    if w_imag_config_accepted = '1' then
                        r_imag_config_valid <= '0';
                    end if;

                when s_advance =>
                    r_reload_set_done <= '1';

                    if refill_threshold_sets > 0 and refill_threshold_sets < block_set_count then
                        if r_set_index = block_set_count - refill_threshold_sets - 1 then
                            r_refill_request <= '1';
                            r_refill_request_pulse <= '1';
                        end if;
                    end if;

                    if r_set_index = block_set_count - 1 then
                        r_reload_block_done <= '1';
                        r_set_index         <= 0;
                    else
                        r_set_index <= r_set_index + 1;
                    end if;

                when s_fault_hold =>
                    null;
            end case;

            state <= next_state;
        end if;
    end process;

    process(state, enable, w_fu_tick, w_fifo_has_complete_set, r_reload_word_index, w_reload_accepted, w_config_accepted)
    begin
        next_state <= state;

        case state is
            when s_idle =>
                next_state <= s_wait_fu;

            when s_wait_fu =>
                if enable = '1' and w_fu_tick = '1' and w_fifo_has_complete_set = '1' then
                    next_state <= s_reload;
                end if;

            when s_reload =>
                if w_reload_accepted = '1' and r_reload_word_index = G_RELOAD_WORD_COUNT - 1 then
                    next_state <= s_config;
                end if;

            when s_config =>
                if w_config_accepted = '1' then
                    next_state <= s_advance;
                end if;

            when s_advance =>
                next_state <= s_wait_fu;

            when s_fault_hold =>
                next_state <= s_wait_fu;
        end case;
    end process;

    w_fu_tick                      <= '1' when enable = '1' and fu_period_cycles /= to_unsigned(0, fu_period_cycles'length) and r_fu_counter = fu_period_cycles - 1 else '0';
    w_fifo_resetn                  <= aresetn;
    w_fifo_usedw_unsigned          <= unsigned(w_xpm_sync_fifo_i_buffer_fifo_usedw);
    w_fifo_has_complete_set        <= '1' when aresetn = '1' and w_fifo_usedw_unsigned >= to_unsigned(G_RELOAD_WORD_COUNT, w_fifo_usedw_unsigned'length) else '0';
    w_set_input_ready              <= '1' when enable = '1' and w_fifo_full = '0' else '0';
    w_timing_fault_candidate       <= '1' when w_fu_tick = '1' and (state = s_reload or state = s_config or state = s_advance) else '0';
    w_xpm_sync_i_buffer_fifo_wrreq <= coeff_set_tvalid and w_set_input_ready;
    w_reload_last                  <= '1' when state = s_reload and r_reload_word_index = G_RELOAD_WORD_COUNT - 1 else '0';
    w_real_reload_accepted         <= r_real_reload_valid and real_reload_tready;
    w_imag_reload_accepted         <= r_imag_reload_valid and imag_reload_tready;
    w_reload_accepted              <= (r_real_reload_valid or r_imag_reload_valid) and ((not r_real_reload_valid) or real_reload_tready) and ((not r_imag_reload_valid) or imag_reload_tready);
    w_xpm_sync_fifo_i_fifo_rdreq   <= '1' when state = s_reload and r_real_reload_valid = '0' and r_imag_reload_valid = '0' and w_fifo_empty = '0' else '0';
    w_real_config_accepted         <= r_real_config_valid and real_config_tready;
    w_imag_config_accepted         <= r_imag_config_valid and imag_config_tready;
    w_config_accepted              <= (r_real_config_valid or r_imag_config_valid) and ((not r_real_config_valid) or real_config_tready) and ((not r_imag_config_valid) or imag_config_tready);

    -- synthesis translate_off
    process(aclk)
    begin
        if rising_edge(aclk) then
            if aresetn = '1' and enable = '1' then
                assert not (state = s_wait_fu and w_fu_tick = '1' and next_state = s_reload and w_fifo_has_complete_set = '0')
                report "Reload started before one complete coefficient set was staged in the FIFO"
                severity failure;

                assert not (w_xpm_sync_fifo_i_fifo_rdreq = '1' and w_fifo_empty = '1')
                report "Sequencer attempted to read an empty coefficient FIFO"
                severity failure;
            end if;
        end if;
    end process;
    -- synthesis translate_on

    coeff_set_tready <= w_set_input_ready;

    real_reload_tvalid <= r_real_reload_valid;
    imag_reload_tvalid <= r_imag_reload_valid;
    real_reload_tdata  <= r_real_reload_data;
    imag_reload_tdata  <= r_imag_reload_data;
    real_reload_tlast  <= r_reload_last;
    imag_reload_tlast  <= r_reload_last;

    real_config_tvalid <= r_real_config_valid;
    imag_config_tvalid <= r_imag_config_valid;
    real_config_tdata  <= (others => '0');
    imag_config_tdata  <= (others => '0');

    reload_active       <= '1' when state = s_reload or state = s_config or state = s_advance else '0';
    reload_set_done     <= r_reload_set_done;
    reload_block_done   <= r_reload_block_done;
    missed_refill       <= r_missed_refill;
    refill_request      <= r_refill_request;
    refill_request_pulse <= r_refill_request_pulse;
    reload_timing_error <= r_reload_timing_error;
    dbg_fu_tick_o       <= w_fu_tick;
    dbg_next_state_o    <= f_state_debug(next_state);
    dbg_reload_accept_o <= w_reload_accepted;
    dbg_config_accept_o <= w_config_accepted;
    dbg_timing_fault_o  <= w_timing_fault_candidate;
    dbg_reload_word_index_o <= std_logic_vector(to_unsigned(r_reload_word_index, dbg_reload_word_index_o'length));
    dbg_reload_set_index_o  <= std_logic_vector(to_unsigned(r_set_index, dbg_reload_set_index_o'length));
    dbg_seq_fifo_usedw_o    <= w_xpm_sync_fifo_i_buffer_fifo_usedw;
    dbg_seq_fifo_has_set_o  <= w_fifo_has_complete_set;
    dbg_seq_input_ready_o   <= w_set_input_ready;

    set_fifo_inst : xpm_fifo_sync_wrap
        generic map(
            g_TYPE                   => "block",
            g_DATA_WIDTH             => C_FIFO_WIDTH,
            g_DEPTH                  => G_FIFO_DEPTH,
            g_FWFT_MODE_ENA          => true,
            g_ALMOST_FULL_THRESHOLD  => G_FIFO_DEPTH - 5,
            g_ALMOST_EMPTY_THRESHOLD => 5
        )
        port map(
            i_resetn       => w_fifo_resetn,
            i_clk          => aclk,
            i_wrreq        => w_xpm_sync_i_buffer_fifo_wrreq,
            i_data         => coeff_set_tdata,
            i_rdreq        => w_xpm_sync_fifo_i_fifo_rdreq,
            o_q_val        => open,
            o_q            => w_xpm_sync_fifo_i_buffer_fifo_q,
            o_usedw        => w_xpm_sync_fifo_i_buffer_fifo_usedw,
            o_full         => w_fifo_full,
            o_empty        => w_fifo_empty,
            o_almost_full  => open,
            o_almost_empty => open
        );

end architecture;
